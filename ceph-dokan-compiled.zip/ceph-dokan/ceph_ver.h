#ifndef CEPH_VERSION_H
#define CEPH_VERSION_H

#define CEPH_GIT_VER 088fcbdd3046210be23fd1bcc32de0892f3f7205
#define CEPH_GIT_NICE_VER "0.94.2"

#endif
